﻿using CP2.Data.AppData;
using CP2.Domain.Entities;
using CP2.Domain.Interfaces;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace CP2.Data.Repositories
{
    public class FornecedorRepository : IFornecedorRepository
    {
        private readonly ApplicationContext _context;

        public FornecedorRepository(ApplicationContext context)
        {
            _context = context;
        }

        public async Task<FornecedorEntity> SalvarDadosAsync(FornecedorEntity fornecedor)
        {
            _context.Fornecedor.Add(fornecedor);
            await _context.SaveChangesAsync();
            return fornecedor;
        }

        public async Task<FornecedorEntity?> EditarDadosAsync(FornecedorEntity fornecedor)
        {
            var fornecedorExistente = await _context.Fornecedor.FindAsync(fornecedor.Id);
            if (fornecedorExistente == null)
            {
                return null;
            }

            _context.Entry(fornecedorExistente).CurrentValues.SetValues(fornecedor);
            await _context.SaveChangesAsync();
            return fornecedorExistente;
        }

        public async Task<FornecedorEntity?> ObterPorIdAsync(int id)
        {
            return await _context.Fornecedor.FindAsync(id);
        }

        public async Task<IEnumerable<FornecedorEntity>> ObterTodosAsync()
        {
            return await _context.Fornecedor.ToListAsync();
        }

        public async Task<bool> DeletarDadosAsync(int id)
        {
            var fornecedor = await _context.Fornecedor.FindAsync(id);
            if (fornecedor == null)
            {
                return false; // Retorna false se o fornecedor não for encontrado.
            }

            _context.Fornecedor.Remove(fornecedor);
            await _context.SaveChangesAsync();
            return true; // Retorna true após a exclusão bem-sucedida.
        }
    }
}
