﻿using CP2.Data.AppData;
using CP2.Domain.Entities;
using CP2.Domain.Interfaces;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace CP2.Data.Repositories
{
    public class VendedorRepository : IVendedorRepository
    {
        private readonly ApplicationContext _context;

        public VendedorRepository(ApplicationContext context)
        {
            _context = context;
        }

        public async Task<IEnumerable<VendedorEntity>> ObterTodosAsync()
        {
            return await _context.Vendedor.ToListAsync();
        }

        public async Task<VendedorEntity?> ObterPorIdAsync(int id)
        {
            return await _context.Vendedor.FindAsync(id);
        }

        public async Task<VendedorEntity> SalvarDadosAsync(VendedorEntity vendedor)
        {
            _context.Vendedor.Add(vendedor);
            await _context.SaveChangesAsync();
            return vendedor;
        }

        public async Task<VendedorEntity?> EditarDadosAsync(VendedorEntity vendedor)
        {
            var vendedorExistente = await _context.Vendedor.FindAsync(vendedor.Id);
            if (vendedorExistente == null)
            {
                return null;
            }

            _context.Entry(vendedorExistente).CurrentValues.SetValues(vendedor);
            await _context.SaveChangesAsync();

            return vendedorExistente;
        }

        public async Task<bool> DeletarDadosAsync(int id)
        {
            var vendedorExistente = await _context.Vendedor.FindAsync(id);
            if (vendedorExistente == null)
            {
                return false;
            }

            _context.Vendedor.Remove(vendedorExistente);
            await _context.SaveChangesAsync();
            return true;
        }
    }
}
