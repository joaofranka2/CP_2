﻿using CP2.Domain.Entities;
using CP2.Domain.Interfaces.Dtos;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace CP2.Domain.Interfaces
{
    public interface IFornecedorApplicationService
    {
        Task<FornecedorEntity> SalvarDadosFornecedor(IFornecedorDto fornecedorDto);
        Task<FornecedorEntity?> EditarDadosFornecedor(int id, IFornecedorDto fornecedorDto);
        Task<FornecedorEntity?> ObterFornecedorPorId(int id);
        Task<IEnumerable<FornecedorEntity>> ObterTodosFornecedores();
        Task<bool> DeletarDadosFornecedor(int id); // Retorna um bool indicando sucesso/falha.
        // Ou, se preferir retornar a entidade deletada:
        // Task<FornecedorEntity?> DeletarDadosFornecedor(int id); 
    }
}
