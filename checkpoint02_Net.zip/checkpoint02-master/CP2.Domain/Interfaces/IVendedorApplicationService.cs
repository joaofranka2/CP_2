﻿using CP2.Domain.Entities;
using CP2.Domain.Interfaces.Dtos;
using System.Threading.Tasks;

namespace CP2.Domain.Interfaces
{
    public interface IVendedorApplicationService
    {
        Task<VendedorEntity> SalvarDadosVendedor(IVendedorDto vendedorDto);
        Task<VendedorEntity?> EditarDadosVendedor(int id, IVendedorDto vendedorDto);
        Task<VendedorEntity?> ObterVendedorPorId(int id);
        Task<IEnumerable<VendedorEntity>> ObterTodosVendedores();
        Task<bool> DeletarDadosVendedor(int id);
    }
}
