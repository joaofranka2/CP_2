﻿using CP2.Domain.Entities;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace CP2.Domain.Interfaces
{
    public interface IVendedorRepository
    {
        Task<VendedorEntity> SalvarDadosAsync(VendedorEntity vendedor);
        Task<VendedorEntity?> EditarDadosAsync(VendedorEntity vendedor);
        Task<VendedorEntity?> ObterPorIdAsync(int id);
        Task<IEnumerable<VendedorEntity>> ObterTodosAsync();
        Task<bool> DeletarDadosAsync(int id);
    }
}
