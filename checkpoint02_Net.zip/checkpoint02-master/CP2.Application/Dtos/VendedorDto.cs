﻿using CP2.Domain.Interfaces.Dtos;
using FluentValidation;
using System;

namespace CP2.Application.Dtos
{
    public class VendedorDto : IVendedorDto
    {
        public string Nome { get; set; }
        public string Email { get; set; }
        public string Telefone { get; set; }
        public DateTime DataNascimento { get; set; }
        public string Endereco { get; set; }
        public DateTime DataContratacao { get; set; }
        public decimal ComissaoPercentual { get; set; }
        public decimal MetaMensal { get; set; }
        public DateTime CriadoEm { get; set; } // Propriedade adicionada para conformidade com a interface.

        /// <summary>
        /// Método para validar os dados do VendedorDto.
        /// </summary>
        public void Validate()
        {
            var validationResult = new VendedorDtoValidation().Validate(this);

            if (!validationResult.IsValid)
                throw new Exception(string.Join(" | ", validationResult.Errors.Select(e => e.ErrorMessage)));
        }
    }

    /// <summary>
    /// Classe de validação para o VendedorDto utilizando FluentValidation.
    /// </summary>
    internal class VendedorDtoValidation : AbstractValidator<VendedorDto>
    {
        public VendedorDtoValidation()
        {
            RuleFor(v => v.Nome)
                .NotEmpty().WithMessage("O nome do vendedor é obrigatório.")
                .MaximumLength(100).WithMessage("O nome do vendedor deve ter no máximo 100 caracteres.");

            RuleFor(v => v.Email)
                .NotEmpty().WithMessage("O e-mail é obrigatório.")
                .EmailAddress().WithMessage("O e-mail fornecido não é válido.");

            RuleFor(v => v.Telefone)
                .NotEmpty().WithMessage("O telefone é obrigatório.")
                .Matches(@"^\d{10,15}$").WithMessage("O telefone deve conter entre 10 e 15 dígitos.");

            RuleFor(v => v.DataNascimento)
                .NotEmpty().WithMessage("A data de nascimento é obrigatória.")
                .LessThan(DateTime.Now).WithMessage("A data de nascimento deve ser anterior à data atual.");

            RuleFor(v => v.Endereco)
                .NotEmpty().WithMessage("O endereço é obrigatório.")
                .MaximumLength(200).WithMessage("O endereço deve ter no máximo 200 caracteres.");

            RuleFor(v => v.DataContratacao)
                .NotEmpty().WithMessage("A data de contratação é obrigatória.")
                .GreaterThanOrEqualTo(v => v.DataNascimento.AddYears(18))
                .WithMessage("A data de contratação deve ser após a data de nascimento, respeitando a idade mínima de 18 anos.");

            RuleFor(v => v.ComissaoPercentual)
                .InclusiveBetween(0, 100).WithMessage("A comissão percentual deve ser entre 0 e 100.");

            RuleFor(v => v.MetaMensal)
                .GreaterThan(0).WithMessage("A meta mensal deve ser um valor positivo.");

            RuleFor(v => v.CriadoEm)
                .NotEmpty().WithMessage("A data de criação é obrigatória.")
                .LessThanOrEqualTo(DateTime.Now).WithMessage("A data de criação deve ser anterior ou igual à data atual.");
        }
    }
}
