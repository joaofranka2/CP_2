﻿using CP2.Domain.Entities;
using CP2.Domain.Interfaces;
using CP2.Domain.Interfaces.Dtos;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace CP2.Application.Services
{
    public class VendedorApplicationService : IVendedorApplicationService
    {
        private readonly IVendedorRepository _repository;

        public VendedorApplicationService(IVendedorRepository repository)
        {
            _repository = repository;
        }

        public async Task<VendedorEntity> SalvarDadosVendedor(IVendedorDto vendedorDto)
        {
            // Valida os dados do DTO antes de salvar
            vendedorDto.Validate();

            // Mapeia o DTO para a entidade
            var vendedor = new VendedorEntity
            {
                Nome = vendedorDto.Nome,
                Email = vendedorDto.Email,
                Telefone = vendedorDto.Telefone,
                DataNascimento = vendedorDto.DataNascimento,
                Endereco = vendedorDto.Endereco,
                DataContratacao = vendedorDto.DataContratacao,
                ComissaoPercentual = vendedorDto.ComissaoPercentual,
                MetaMensal = vendedorDto.MetaMensal,
                CriadoEm = vendedorDto.CriadoEm
            };

            // Salva no repositório e retorna a entidade salva
            return await _repository.SalvarDadosAsync(vendedor);
        }

        public async Task<VendedorEntity?> EditarDadosVendedor(int id, IVendedorDto vendedorDto)
        {
            // Valida os dados do DTO antes de atualizar
            vendedorDto.Validate();

            // Obtém o vendedor existente pelo ID
            var vendedorExistente = await _repository.ObterPorIdAsync(id);
            if (vendedorExistente == null)
            {
                return null; // Retorna null se o vendedor não for encontrado.
            }

            // Atualiza os dados do vendedor com as informações do DTO
            vendedorExistente.Nome = vendedorDto.Nome;
            vendedorExistente.Email = vendedorDto.Email;
            vendedorExistente.Telefone = vendedorDto.Telefone;
            vendedorExistente.DataNascimento = vendedorDto.DataNascimento;
            vendedorExistente.Endereco = vendedorDto.Endereco;
            vendedorExistente.DataContratacao = vendedorDto.DataContratacao;
            vendedorExistente.ComissaoPercentual = vendedorDto.ComissaoPercentual;
            vendedorExistente.MetaMensal = vendedorDto.MetaMensal;

            // Salva as alterações no repositório
            var resultado = await _repository.EditarDadosAsync(vendedorExistente);

            // Retorna a entidade atualizada
            return resultado;
        }

        public async Task<VendedorEntity?> ObterVendedorPorId(int id)
        {
            // Obtém o vendedor pelo ID
            return await _repository.ObterPorIdAsync(id);
        }

        public async Task<IEnumerable<VendedorEntity>> ObterTodosVendedores()
        {
            // Obtém todos os vendedores do repositório
            return await _repository.ObterTodosAsync();
        }

        public async Task<bool> DeletarDadosVendedor(int id)
        {
            // Deleta o vendedor pelo ID e retorna o resultado da operação
            return await _repository.DeletarDadosAsync(id);
        }
    }
}


