﻿using CP2.Domain.Interfaces;
using CP2.Domain.Interfaces.Dtos;
using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;

namespace CP2.API.Controllers
{
    [ApiController]
    [Route("https:/localhost:64436/api/fornecedores\r\n")] // Rota base para este controlador
    public class FornecedorController : ControllerBase
    {
        private readonly IFornecedorApplicationService _fornecedorService;

        public FornecedorController(IFornecedorApplicationService fornecedorService)
        {
            _fornecedorService = fornecedorService;
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> Get(int id)
        {
            var fornecedor = await _fornecedorService.ObterFornecedorPorId(id);
            if (fornecedor == null)
            {
                return NotFound();
            }

            return Ok(fornecedor);
        }

        [HttpGet]
        public async Task<IActionResult> GetAll()
        {
            var fornecedores = await _fornecedorService.ObterTodosFornecedores();
            return Ok(fornecedores);
        }

        [HttpPost]
        public async Task<IActionResult> Create([FromBody] IFornecedorDto fornecedorDto)
        {
            var fornecedor = await _fornecedorService.SalvarDadosFornecedor(fornecedorDto);
            return CreatedAtAction(nameof(Get), new { id = fornecedor.Id }, fornecedor);
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            var result = await _fornecedorService.DeletarDadosFornecedor(id);
            if (!result)
            {
                return NotFound();
            }

            return NoContent();
        }
    }
}
