﻿using Microsoft.AspNetCore.Mvc;
using CP2.Domain.Interfaces;
using CP2.Domain.Interfaces.Dtos;
using System.Threading.Tasks;
using CP2.Application.Dtos;

namespace CP2.API.Controllers
{
    [ApiController]
    [Route("\"https:/localhost:64436/api/fornecedores\\r\\n\"")]
    public class VendedorController : ControllerBase
    {
        private readonly IVendedorApplicationService _vendedorService;

        public VendedorController(IVendedorApplicationService vendedorService)
        {
            _vendedorService = vendedorService;
        }

        /// <summary>
        /// Obtém a lista de todos os vendedores.
        /// </summary>
        [HttpGet]
        public async Task<IActionResult> GetAll()
        {
            var vendedores = await _vendedorService.ObterTodosVendedores();
            return Ok(vendedores);
        }

        /// <summary>
        /// Obtém um vendedor pelo ID.
        /// </summary>
        /// <param name="id">ID do vendedor.</param>
        [HttpGet("{id}")]
        public async Task<IActionResult> Get(int id)
        {
            var vendedor = await _vendedorService.ObterVendedorPorId(id);
            if (vendedor == null)
                return NotFound("Vendedor não encontrado.");

            return Ok(vendedor);
        }

        /// <summary>
        /// Cria um novo vendedor.
        /// </summary>
        /// <param name="vendedorDto">Dados do vendedor.</param>
        [HttpPost]
        public async Task<IActionResult> Create([FromBody] VendedorDto vendedorDto)
        {
            if (vendedorDto == null)
                return BadRequest("Dados inválidos.");

            var vendedor = await _vendedorService.SalvarDadosVendedor(vendedorDto);
            return CreatedAtAction(nameof(Get), new { id = vendedor.Id }, vendedor);
        }

        /// <summary>
        /// Atualiza um vendedor existente.
        /// </summary>
        /// <param name="id">ID do vendedor a ser atualizado.</param>
        /// <param name="vendedorDto">Novos dados do vendedor.</param>
        [HttpPut("{id}")]
        public async Task<IActionResult> Update(int id, [FromBody] VendedorDto vendedorDto)
        {
            if (vendedorDto == null)
                return BadRequest("Dados inválidos.");

            var vendedorAtualizado = await _vendedorService.EditarDadosVendedor(id, vendedorDto);
            if (vendedorAtualizado == null)
                return NotFound("Vendedor não encontrado para atualização.");

            return Ok(vendedorAtualizado);
        }

        /// <summary>
        /// Exclui um vendedor pelo ID.
        /// </summary>
        /// <param name="id">ID do vendedor a ser excluído.</param>
        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            var sucesso = await _vendedorService.DeletarDadosVendedor(id);
            if (!sucesso)
                return NotFound("Vendedor não encontrado para exclusão.");

            return NoContent(); // Retorna 204 - No Content.
        }
    }
}
