﻿using Microsoft.Extensions.DependencyInjection;
using CP2.Domain.Interfaces;
using CP2.Application.Services;
using CP2.Data.Repositories;

namespace CP2.IoC
{
    public static class Bootstrap
    {
        public static void RegisterServices(this IServiceCollection services)
        {
            // Registra os repositórios e serviços de aplicação.
            services.AddTransient<IFornecedorRepository, FornecedorRepository>();
            services.AddTransient<IVendedorRepository, VendedorRepository>();

            services.AddTransient<IFornecedorApplicationService, FornecedorApplicationService>();
            services.AddTransient<IVendedorApplicationService, VendedorApplicationService>();
        }
    }
}
