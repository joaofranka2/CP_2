﻿using Microsoft.AspNetCore.Mvc;
using CP2.Domain.Interfaces;

[ApiController]
[Route("api/vendedores")]
public class VendedorController : ControllerBase
{
    private readonly IVendedorApplicationService _vendedorService;

    public VendedorController(IVendedorApplicationService vendedorService)
    {
        _vendedorService = vendedorService;
    }

    [HttpGet]
    public IActionResult GetAll()
    {
        var vendedores = _vendedorService.ObterTodosVendedores();
        return Ok(vendedores);
    }
}
