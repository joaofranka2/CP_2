﻿using CP2.Domain.Entities;
using CP2.Domain.Interfaces;
using CP2.Domain.Interfaces.Dtos;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace CP2.Application.Services
{
    public class FornecedorApplicationService : IFornecedorApplicationService
    {
        private readonly IFornecedorRepository _repository;

        public FornecedorApplicationService(IFornecedorRepository repository)
        {
            _repository = repository;
        }

        public async Task<FornecedorEntity> SalvarDadosFornecedor(IFornecedorDto fornecedorDto)
        {
            fornecedorDto.Validate();

            var fornecedor = new FornecedorEntity
            {
                Nome = fornecedorDto.Nome,
                CNPJ = fornecedorDto.CNPJ,
                Endereco = fornecedorDto.Endereco,
                CriadoEm = fornecedorDto.CriadoEm
            };

            return await _repository.SalvarDadosAsync(fornecedor);
        }

        public async Task<FornecedorEntity?> EditarDadosFornecedor(int id, IFornecedorDto fornecedorDto)
        {
            fornecedorDto.Validate();

            var fornecedorExistente = await _repository.ObterPorIdAsync(id);
            if (fornecedorExistente == null)
            {
                return null;
            }

            fornecedorExistente.Nome = fornecedorDto.Nome;
            fornecedorExistente.CNPJ = fornecedorDto.CNPJ;
            fornecedorExistente.Endereco = fornecedorDto.Endereco;

            return await _repository.EditarDadosAsync(fornecedorExistente);
        }

        public async Task<FornecedorEntity?> ObterFornecedorPorId(int id)
        {
            return await _repository.ObterPorIdAsync(id);
        }

        public async Task<IEnumerable<FornecedorEntity>> ObterTodosFornecedores()
        {
            return await _repository.ObterTodosAsync();
        }

        public async Task<bool> DeletarDadosFornecedor(int id)
        {
            // Chama o método do repositório para deletar o fornecedor e retorna o resultado.
            return await _repository.DeletarDadosAsync(id);
        }

        // Caso prefira retornar a entidade deletada, altere o método para:
        /*
        public async Task<FornecedorEntity?> DeletarDadosFornecedor(int id)
        {
            var fornecedor = await _repository.ObterPorIdAsync(id);
            if (fornecedor == null)
            {
                return null; // Retorna null se o fornecedor não for encontrado.
            }

            var result = await _repository.DeletarDadosAsync(id);
            return result ? fornecedor : null; // Retorna o fornecedor deletado se a operação foi bem-sucedida.
        }
        */
    }
}
