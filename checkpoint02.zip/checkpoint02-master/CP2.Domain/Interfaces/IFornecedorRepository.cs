﻿using CP2.Domain.Entities;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace CP2.Domain.Interfaces
{
    public interface IFornecedorRepository
    {
        Task<FornecedorEntity> SalvarDadosAsync(FornecedorEntity fornecedor);
        Task<FornecedorEntity?> EditarDadosAsync(FornecedorEntity fornecedor);
        Task<FornecedorEntity?> ObterPorIdAsync(int id);
        Task<IEnumerable<FornecedorEntity>> ObterTodosAsync();
        Task<bool> DeletarDadosAsync(int id); // Método para deletar um fornecedor pelo ID.
    }
}
